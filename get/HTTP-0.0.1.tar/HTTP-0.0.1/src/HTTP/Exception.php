<?php
/**
 * Exception classes
 */

/**
 * Base class for exceptions in PEAR
 */
require_once 'PEAR/Exception.php';

class HTTP_Exception extends PEAR_Exception
{
}
?>
