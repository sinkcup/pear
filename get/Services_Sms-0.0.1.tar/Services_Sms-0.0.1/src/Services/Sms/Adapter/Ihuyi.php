<?php
/**
 * Adapter for Services_Sms 互亿无线（ihuyi.com）短信通道
 *
 * PHP version 5
 */

require_once 'Services/Sms/Adapter.php';

class Services_Sms_Adapter_Ihuyi extends Services_Sms_Adapter
{
    protected $conf = array(
        'name'   => null,
        'pwd'    => null,
        'corpid' => null,
        'prdid'  => null,
        'apiUriPrefix'    => 'http://60.28.200.150/submitdata/service.asmx',
    );

    public function __construct($conf)
    {
        parent::__construct($conf);
    }
    public function send($mobile, $content)
    {
        $data = array(
            'sname'=>$this->conf['name'],
            'spwd'=>$this->conf['pwd'],
            'scorpid'=>$this->conf['corpid'],
            'sprdid'=>$this->conf['prdid'],
            'sdst'=>$mobile,
            'smsg'=>$content . $this->conf['sign']
        );

        $http = new HTTP_Request2($this->conf['apiUriPrefix'] . '/g_Submit', HTTP_Request2::METHOD_POST);
        $http->addPostParameter($data);
        $r = $http->send();

        if ($filter = $this->filter($r->getBody())) {
            return $filter;
        }

        return true;         
    }

    private function filter($str)
    {
        if (preg_match('/<\?xml\s+.+$/is', $str, $matches)) {
            $xml = simplexml_load_string($matches[0]);
            return get_object_vars($xml);
        }
        return false;
    }
}
?>
