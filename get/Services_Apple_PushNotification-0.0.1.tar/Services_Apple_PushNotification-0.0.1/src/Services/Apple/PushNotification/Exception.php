<?php
/**
 * Exception classes
 */

/**
 * Base class for exceptions in PEAR
 */
require_once 'PEAR/Exception.php';

class Services_Apple_PushNotification_Exception extends PEAR_Exception
{
}
?>
