这里面除了Exception.php，其他是百度官方sdk带的垃圾。
