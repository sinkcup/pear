<?php
/**
 * Base class for adapters
 *
 * PHP version 5
 */

require_once 'HTTP/Request2.php';

abstract class Services_Sms_Adapter
{
    protected $conf = array();

    public function __construct($conf)
    {
        $this->conf = array_merge($this->conf, $conf);
    }

    public function send($mobile, $content)
    {
    }
}
?>
