<?php
/**
 * 发短信
 *
 * @category Services
 * @package  Services_Sms
 * @author   sink <sinkcup@163.com>
 * @license  http://opensource.org/licenses/bsd-license.php New BSD License
 * @link     http://pear.php.net/package/Services_Sms
 */

require_once 'Services/Sms/Adapter/Ihuyi.php';

class Services_Sms
{
    protected $adapter;

    public function __construct($getway, array $conf)
    {
        $className = 'Services_Sms_Adapter_' . ucfirst($getway);
        $this->adapter = new $className($conf);
    }

    public function send($mobile, $content)
    {
        return $this->adapter->send($mobile, $content);
    }
}
?>
