<?php
/**
 * Exception classes
 */

/**
 * Base class for exceptions in PEAR
 */
require_once 'PEAR/Exception.php';

class Services_Aliyun_OSS_Exception extends PEAR_Exception
{
}
?>
